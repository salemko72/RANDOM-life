import {adEvent,hasNativeAds} from './ads-bridge';
import ShareAppControl from'./ShareAppControl';
import{useNativeBack}from'./useNativeBack';
import{backAction}from'../native/back-navigation';
import CatalogControls from './CatalogControls';
import BrandLogo from './BrandLogo';
import {performanceEvent,exportPerformance,summarizeFrames,motionReduced} from './performance';
/// <reference path="./image-assets.d.ts" />
import {ingredientSpriteStyle} from './ingredient-atlas';
import {InterfaceSfx,loadSfx} from './sfx';
import React, { useEffect, useRef, useState } from 'react';
import { localizeContent, publicationIssues, resolveIngredient, type ContentRecord } from '@random/shared';
import ContentStudio from '../../../studio/src/App';
import { readPreviewCatalog, readPreviewImage } from '../../../studio/src/preview-store';
import '../../../studio/src/styles.css';
import './experience.css';
import Icon from './Icon';
import ArtworkMasks from './ArtworkMasks';
import ItemActions from './ItemActions';
import {consumerCatalogStatus} from './bundled-catalog';
import ImageViewer from './ImageViewer';
import AccessLinks from './AccessLinks';
import {LanguageProvider, LanguageChooser, useLanguage, translate} from './ui-language';
import {type PreviewRecord} from './watch';
import Onboarding from './Onboarding';
import {companionItems,type Companion} from './companions';
import {loadProfile,saveProfile,createProfile,setPersonalization,recordSignal,selectPersonalized,cycleCandidates,choosePersonalizedCategory,eligibleForProfile,explainPreference,type Profile,type SignalKind,type UiCategory,toggleCompleted} from './preferences';
import {loadExperience,saveExperience} from './experience-state';
import {deleteDeviceProfile} from './delete-profile';
import { WHEEL_CATEGORIES as BASE_WHEEL_CATEGORIES, itemWheelChoices, coast, landingRotation, sectorAtRotation, type ActiveCategory } from './wheel';

const WHEEL_CATEGORIES=BASE_WHEEL_CATEGORIES;
type WheelCategory=typeof WHEEL_CATEGORIES[number]['id'];
type SpinCategory=ActiveCategory;
const approvedCatalogs=new WeakMap<ContentRecord[],ContentRecord[]>();
function approvedCatalog(rows:ContentRecord[]){
 let approved=approvedCatalogs.get(rows);
 if(!approved){approved=rows.filter(r=>r.status==='published'&&!publicationIssues(r).length);approvedCatalogs.set(rows,approved);}
 return approved;
}
function uiCategory(r:PreviewRecord):UiCategory{return r.category==='BOOK'?'READ':r.category;}
function completedLabel(r:PreviewRecord,locale:import("@random/shared").Locale){const t=(text:string)=>translate(text,locale);return r.category==='BOOK'?t("Već čitao/la"):r.category==='WATCH'?t("Već gledao/la"):r.category==='MOVE'?t("Već radio/la"):r.category==='GO'?t("Već bio/la"):t("Već probao/la");}
function action(r:PreviewRecord,locale:import("@random/shared").Locale){const t=(text:string)=>translate(text,locale);return r.category==='EAT'?t("Skuhaj"):r.category==='BOOK'?t("Pročitaj"):r.category==='WATCH'?t("Pogledaj"):r.category==='MOVE'?t("Pokreni se"):t("Izađi");}
function actionLabel(r:PreviewRecord,locale:import("@random/shared").Locale){const t=(text:string)=>translate(text,locale);return r.category==='EAT'?t("LET’S COOK"):r.category==='BOOK'?t("PROČITAJ OVU KNJIGU"):r.category==='WATCH'?t("POGLEDAJ DETALJE"):r.category==='MOVE'?t("KRENIMO"):t("ISPLANIRAJ IZLAZAK");}
function actionIcon(r:PreviewRecord){return r.category==='EAT'?'food':r.category==='BOOK'?'book':r.category==='WATCH'?'watch':r.category==='MOVE'?'move':'pin';}
function imageClass(item:PreviewRecord) { if(['WATCH','MOVE','GO'].includes(item.category))return `photo-${item.id}`; if(item.category==='BOOK')return 'photo-reading';const photos:Record<string,string>={'/media/lentil-soup.png':'photo-soup','/media/potato-salad.png':'photo-potato-salad','/media/swedish-meatballs.png':'photo-swedish-meatballs','/media/menemen.png':'photo-menemen','/media/moussaka.png':'photo-moussaka'};return photos[item.image.path]??'photo-soup'; }
function AppSplash({leaving=false}:{leaving?:boolean}){
 const {locale,t}=useLanguage();
 return <section className={`app-splash ${leaving?'is-leaving':''}`} aria-hidden={leaving} inert={leaving} aria-label={locale==='en'?'Opening LifeSpinner':'Otvaranje LifeSpinner'}>
  <div className="splash-wordmark"><h1><BrandLogo/></h1><p>{t("Decide Less. Live More.")}</p><span className="splash-line" aria-hidden="true"/></div>
  <nav className="splash-legal" aria-label={locale==='en'?'Legal information':'Pravne informacije'}><a href="https://random-life-preview.pages.dev/terms.html" target="_blank" rel="noreferrer">{locale==='en'?'Terms of use':'Uslovi korištenja'}</a><span aria-hidden="true">·</span><a href="https://random-life-preview.pages.dev/privacy.html" target="_blank" rel="noreferrer">{locale==='en'?'Privacy':'Privatnost'}</a></nav>
 </section>;
}
function WheelChoicePhoto({record}:{record:PreviewRecord}){
 const [url,setUrl]=useState<string|null>(null);
 useEffect(()=>{let live=true;let imageUrl:string|undefined;readPreviewImage(record.image.path).then(blob=>{if(blob&&live){imageUrl=URL.createObjectURL(blob);setUrl(imageUrl);}}).catch(()=>{});return()=>{live=false;if(imageUrl)URL.revokeObjectURL(imageUrl);};},[record.id,record.image.path]);
 return <span className={`wheel-choice-photo ${imageClass(record)}`} style={url?{backgroundImage:`url(${url})`,backgroundSize:'cover',backgroundPosition:'center'}:undefined}/>;
}
function SavedPhoto({record}:{record:PreviewRecord}){
 const key=`${record.id}:${record.version}:${record.image.path}`;
 const [loaded,setLoaded]=useState<{key:string;url:string}|null>(null);
 useEffect(()=>{let live=true;let url:string|undefined;readPreviewImage(record.image.path).then(blob=>{if(blob&&live){url=URL.createObjectURL(blob);setLoaded({key,url});}}).catch(()=>{});return()=>{live=false;if(url)URL.revokeObjectURL(url);};},[key,record.image.path]);
 const url=loaded?.key===key?loaded.url:null;
 return <span className="saved-photo" data-item-image={record.image.path} aria-hidden="true" style={{backgroundImage:url?`url("${url}")`:'none'}}>{!url&&<Icon name={actionIcon(record)} size={22}/>}</span>;
}
function choiceLines(text:string){const lines:string[]=[];let line='';for(const word of text.split(/\s+/)){if(line&&line.length+word.length>17){lines.push(line);line=word;}else line+=(line?' ':'')+word;}if(line)lines.push(line);return lines.slice(0,3).map((l,i)=>i===2&&lines.length>3?l.slice(0,15)+'…':l);}
// Bundled generic photography: independent of D1 and available offline.
function WheelCategoryArtwork({category,index}:{category:WheelCategory;index:number}){
 return <g data-category-artwork={category} transform={`rotate(${index*(360/WHEEL_CATEGORIES.length)} 300 300)`} aria-hidden="true"><foreignObject x="120" y="0" width="360" height="330"><div className={`wheel-default-photo wheel-default-${category.toLowerCase()}`}/></foreignObject></g>;
}
function Wheel({ rotor, tick, spinning, onSpin, onSpinCategory, choices }: {rotor:React.RefObject<HTMLDivElement|null>;tick:number;spinning:boolean;onSpin:()=>void;onSpinCategory:(category:SpinCategory)=>void;choices:PreviewRecord[]|null}) {
  const {t,category,locale}=useLanguage();
  const segments=choices??WHEEL_CATEGORIES;const degrees=360/segments.length;
  function sector(index:number) {if(segments.length===1)return 'M300 14 A286 286 0 1 1 300 586 A286 286 0 1 1 300 14 Z';const start=(index*degrees-90-degrees/2)*Math.PI/180,end=(index*degrees-90+degrees/2)*Math.PI/180;return `M300 300 L${300+286*Math.cos(start)} ${300+286*Math.sin(start)} A286 286 0 ${degrees>180?1:0} 1 ${300+286*Math.cos(end)} ${300+286*Math.sin(end)} Z`;}
  return <div className={`wheel-stage ${spinning?'is-spinning':''} ${choices?'item-wheel':'category-wheel'}`} data-wheel-mode={choices?'items':'categories'}>
    <div className="wheel-rotor" ref={rotor}><svg className="wheel-svg" viewBox="0 0 600 600" role="group" aria-label={locale==='en'?'Wheel categories':'Kategorije na wheelu'} aria-hidden={choices?true:undefined}><defs>{segments.map((c,i)=><clipPath id={`sector-${i}`} key={c.id}><path d={sector(i)}/></clipPath>)}</defs>
      <circle cx="300" cy="300" r="299" fill="#f6e3dd"/>
      {segments.map((c,i)=>{const record=choices?.[i];const label=record?localizeContent(record,locale).title:category(c.id);const icon=record?actionIcon(record):WHEEL_CATEGORIES[i].icon;return <g key={c.id} clipPath={`url(#sector-${i})`} data-choice-id={record?.id} data-choice-title={record?label:undefined}>
        <path d={sector(i)} fill={i%2===0?'#ba7d79':'#e9d2c9'} stroke="#f9eee8" strokeWidth="2"/>
        {record&&<foreignObject x="0" y="0" width="600" height="600"><WheelChoicePhoto record={record}/></foreignObject>}

        {!record&&<WheelCategoryArtwork category={WHEEL_CATEGORIES[i].id} index={i}/>}
        <path d={sector(i)} fill="#382324" opacity={record?'.48':'.22'}/>
        <g transform={`rotate(${i*degrees} 300 300)`} fill="#fff6ee">
          {record&&<foreignObject x="273" y="75" width="54" height="60"><div className={`sector-icon ${record||i%2===0?'light':''}`}><Icon name={icon} size={record?32:42}/></div></foreignObject>}
          <text x="300" y={record?159:c.id==='READ'?72:94} textAnchor="middle" fontSize={record?17:19} fontFamily="RandomSans">{record?choiceLines(label).map((line,n)=><tspan key={n} x="300" dy={n?22:0}>{line}</tspan>):label}</text>
        </g>
        {!choices&&<path className="wheel-sector-control" d={sector(i)} fill="transparent" role="button" tabIndex={spinning?-1:0} aria-label={locale==='en'?`Spin in ${label}`:`Zavrti kategoriju ${label}`} aria-disabled={spinning} data-wheel-category={WHEEL_CATEGORIES[i].id} onClick={event=>{event.stopPropagation();if(!spinning)onSpinCategory(WHEEL_CATEGORIES[i].id);}} onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();if(!spinning)onSpinCategory(WHEEL_CATEGORIES[i].id);}}}><title>{label}</title></path>}
      </g>;})}
      {!choices&&<g className="wheel-category-dividers" pointerEvents="none" aria-hidden="true" stroke="#fff4eb" strokeWidth="3" strokeLinecap="round">{WHEEL_CATEGORIES.map((c,i)=>{const angle=(i*degrees-90-degrees/2)*Math.PI/180;return <line key={c.id} x1="300" y1="300" x2={300+286*Math.cos(angle)} y2={300+286*Math.sin(angle)}/>;})}</g>}
      <circle cx="300" cy="300" r="288" fill="none" stroke="#fff4eb" strokeWidth="5"/>
    </svg></div>
    <div className="wheel-pointer" key={tick}><svg viewBox="0 0 60 66"><path d="M9 4h42q7 0 4 8L35 56q-5 10-10 0L5 12Q2 4 9 4Z" fill="#ae6b69" stroke="#e8c4bc" strokeWidth="4"/></svg></div>
    <button className="spin-hub" onClick={onSpin} disabled={spinning} aria-label={spinning?t("Spin je u toku"):t("Pokreni Spin")}><strong>{spinning?t("SPINNING"):t("SPIN")}</strong><span>{spinning?t("nešto dobro dolazi"):t("and go")}</span></button>
  </div>;
}
function ResultMeta({item}:{item:PreviewRecord}){
 const {t,value}=useLanguage();
 let values:{icon:string;label:string}[];
 if(item.category==='EAT')values=[{icon:'clock',label:`${item.totalMinutes} min`},{icon:'chef',label:t("Lako")},{icon:'people',label:`${item.servings} ${t("osobe")}`}];
 else if(item.category==='WATCH')values=[{icon:'watch',label:value(item.format)},{icon:'calendar',label:String(item.year)},{icon:'clock',label:item.durationLabel}];
 else if(item.category==='BOOK')values=item.genres.slice(0,3).map(label=>({icon:'book',label}));
 else values=[{icon:'clock',label:`${item.category==='GO'?t("oko "):''}${item.durationMinutes} min`},{icon:item.category==='MOVE'?'move':'pin',label:value(item.subtype)},{icon:'people',label:item.company==='solo'?t("Sam/a"):item.company==='pair'?t("U paru"):t("Društvo")}];
 return <div className="result-meta">{values.map((v,i)=><span key={i}><Icon name={v.icon} size={18}/><span className="badge-label">{v.label}</span></span>)}</div>;
}
export default function WebExperience(){return <LanguageProvider><Experience/></LanguageProvider>;}
function Experience(){
 const {t,locale,category,value}=useLanguage();
 const [profile,setProfile]=useState(loadProfile);const [entered,setEntered]=useState(()=>profile.onboarded);const [welcomeRendered,setWelcomeRendered]=useState(()=>!profile.onboarded);const [editingProfile,setEditingProfile]=useState(false);const [storageAvailable,setStorageAvailable]=useState(true);
 const [launchPhase,setLaunchPhase]=useState<'splash'|'reveal'|'ready'>(()=>location.hash==='#studio'?'ready':'splash');
 const [studio,setStudio]=useState(location.hash==='#studio');const [scene,setScene]=useState<'home'|'result'>('home');
 const [wheelChoices,setWheelChoices]=useState<PreviewRecord[]|null>(null);const [pointerChoice,setPointerChoice]=useState(0);
 const [saveFlight,setSaveFlight]=useState<{id:number;x:number;y:number;toX:number;toY:number;label:string}|null>(null);const [saveNotice,setSaveNotice]=useState('');
 const mainMenuButton=useRef<HTMLButtonElement>(null),detailHomeButton=useRef<HTMLButtonElement>(null),wasDetails=useRef(false);
 const [item,setItem]=useState<PreviewRecord|null>(null);const [busy,setBusy]=useState(false);const [showSpinCaption,setShowSpinCaption]=useState(false);const [active,setActive]=useState(0);const [tick,setTick]=useState(0);
 type Panel='menu'|'ingredients'|'companions'|'related-info'|'favorites'|'profile'|'history'|null;
 const [panel,setPanel]=useState<Panel>(null);const [renderedPanel,setRenderedPanel]=useState<Panel>(null);const visiblePanel=panel||renderedPanel;const [relatedInfo,setRelatedInfo]=useState<Companion|null>(null);const [details,setDetails]=useState(false);const [message,setMessage]=useState('');
 const initialExperience=useRef(loadExperience(profile.id));const [historyIds,setHistoryIds]=useState(initialExperience.current.history);const [seenIds,setSeenIds]=useState(initialExperience.current.seen);const [favoriteIds,setFavoriteIds]=useState(initialExperience.current.favorites);
 const [catalogError,setCatalogError]=useState('');
 const catalogFailure=(error:unknown)=>error instanceof Error?(error.message.match(/CATALOG_[A-Z0-9_]+/)?.[0]??'CATALOG_CLIENT_ERROR'):'CATALOG_CLIENT_ERROR';
 const [catalogState,setCatalogState]=useState<'loading'|'online'|'cached'|'backup'|'error'>('loading');const [catalogReload,setCatalogReload]=useState(0);
 const [published,setPublished]=useState<ContentRecord[]>([]);const [uploadedImage,setUploadedImage]=useState<string|null>(null);const [imageExpanded,setImageExpanded]=useState(false);
 useEffect(()=>setImageExpanded(false),[item?.id,studio]);
 useEffect(()=>{if(details)detailHomeButton.current?.focus({preventScroll:true});else if(wasDetails.current)mainMenuButton.current?.focus({preventScroll:true});wasDetails.current=details;},[details]);
 const records:PreviewRecord[]=published;
 const [soundEnabled,setSoundEnabled]=useState(loadSfx);const sfx=useRef<InterfaceSfx|null>(null);
 useEffect(()=>{
  if(studio){setLaunchPhase('ready');return;}
  if(launchPhase==='ready')return;
  const timer=setTimeout(()=>setLaunchPhase(launchPhase==='splash'?'reveal':'ready'),launchPhase==='splash'?2000:1000);
  return()=>clearTimeout(timer);
 },[studio,launchPhase]);
 useEffect(()=>{const audio=new InterfaceSfx();sfx.current=audio;audio.setEnabled(loadSfx());const click=(event:MouseEvent)=>{const target=event.target instanceof Element?event.target.closest('button,[role=button],a,input[type=checkbox],select'):null;if(!target||(target instanceof HTMLButtonElement&&target.disabled)||target.getAttribute('aria-disabled')==='true')return;void audio.unlock().then(()=>{if(window.location.hash!=='#studio')audio.welcome();audio.click();});};const visibility=()=>{if(document.visibilityState==='hidden')audio.pause();};document.addEventListener('click',click,true);document.addEventListener('visibilitychange',visibility);window.addEventListener('pagehide',visibility);return()=>{document.removeEventListener('click',click,true);document.removeEventListener('visibilitychange',visibility);window.removeEventListener('pagehide',visibility);audio.dispose();sfx.current=null;};},[]);
 function changeSound(){const enabled=!soundEnabled;setSoundEnabled(enabled);sfx.current?.setEnabled(enabled);if(enabled)void sfx.current?.unlock().then(()=>sfx.current?.click());}
 useEffect(()=>{if(launchPhase==='ready')performanceEvent('ui_ready',{elapsedMs:performance.now()});},[launchPhase]);
 const rotor=useRef<HTMLDivElement>(null);const rotation=useRef(0);const animation=useRef(0);const locked=useRef(false);const mounted=useRef(true);const lastCategory=useRef<UiCategory|undefined>(undefined);
 useEffect(()=>{setStorageAvailable(saveProfile(profile));},[profile]);
 useEffect(()=>{saveExperience(profile.id,{history:historyIds,seen:seenIds,favorites:favoriteIds});},[profile.id,historyIds,seenIds,favoriteIds]);
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;cancelAnimationFrame(animation.current);};},[]);
 useEffect(()=>{const sync=()=>setStudio(location.hash==='#studio');window.addEventListener('hashchange',sync);return()=>window.removeEventListener('hashchange',sync);},[]);
 useEffect(()=>{
  let live=true;
  const load=(force=false)=>readPreviewCatalog(force).then(rows=>{if(live){setPublished(approvedCatalog(rows));setCatalogState(consumerCatalogStatus().source);setCatalogError('');}}).catch(error=>{if(live){setCatalogState('error');setCatalogError(catalogFailure(error));}});
  const normal=()=>{void load();};const forced=()=>{void load(true);};
  void load(catalogReload>0);
  const timer=setInterval(()=>{if(document.visibilityState!=='hidden')void load();},30000);
  window.addEventListener('random-content-updated',forced);window.addEventListener('random-catalog-updated',normal);window.addEventListener('focus',normal);window.addEventListener('pageshow',normal);window.addEventListener('online',forced);
  return()=>{live=false;clearInterval(timer);window.removeEventListener('random-content-updated',forced);window.removeEventListener('random-catalog-updated',normal);window.removeEventListener('focus',normal);window.removeEventListener('pageshow',normal);window.removeEventListener('online',forced);};
 },[studio,catalogReload]);
 useEffect(()=>{let live=true;let url:string|undefined;setUploadedImage(null);if(item)readPreviewImage(item.image.path).then(blob=>{if(blob&&live){url=URL.createObjectURL(blob);setUploadedImage(url);}}).catch(()=>{});return()=>{live=false;if(url)URL.revokeObjectURL(url);};},[item]);
 useEffect(()=>{if(rotor.current)rotor.current.style.transform=`rotate(${rotation.current}deg)`;},[studio]);
 useEffect(()=>{if(!entered)return;const timer=setTimeout(()=>setWelcomeRendered(false),450);return()=>clearTimeout(timer);},[entered]);
 useEffect(()=>{if(panel){setRenderedPanel(panel);return;}const timer=setTimeout(()=>setRenderedPanel(null),220);return()=>clearTimeout(timer);},[panel]);
 useNativeBack(()=>{const action=backAction({busy:busy||locked.current||launchPhase!=='ready',image:imageExpanded,panel:!!visiblePanel,details,result:scene==='result',editing:editingProfile,onboarding:!entered});if(action==='image')setImageExpanded(false);else if(action==='panel')setPanel(null);else if(action==='details')setDetails(false);else if(action==='home')goHome();return action!=='exit';});
 useEffect(()=>{const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'&&!busy&&!imageExpanded){if(editingProfile)window.dispatchEvent(new Event('lifespinner.profile-cancel'));else if(panel)setPanel(null);else if(details)setDetails(false);}};window.addEventListener('keydown',escape);return()=>window.removeEventListener('keydown',escape);},[panel,details,busy,editingProfile,imageExpanded]);
 useEffect(()=>{if(!busy||scene!=='home'){setShowSpinCaption(false);return;}setShowSpinCaption(true);const timer=setTimeout(()=>setShowSpinCaption(false),2000);return()=>clearTimeout(timer);},[busy,scene]);
 useEffect(()=>{const interrupt=()=>adEvent('busy');document.addEventListener('pointerdown',interrupt,true);document.addEventListener('keydown',interrupt,true);return()=>{document.removeEventListener('pointerdown',interrupt,true);document.removeEventListener('keydown',interrupt,true);};},[]);
 useEffect(()=>{if(entered&&launchPhase==='ready')adEvent('ready');},[entered,launchPhase]);
 function signal(record:PreviewRecord,kind:SignalKind){setProfile(p=>recordSignal(p,record,kind));}
 function expose(record:PreviewRecord){setItem(record);setScene('result');setActive(WHEEL_CATEGORIES.findIndex(c=>c.id===uiCategory(record)));setHistoryIds(ids=>[...ids,record.id].slice(-200));setSeenIds(ids=>[...new Set([...ids,record.id])].slice(-200));signal(record,'exposure');}
 function finishProfile(next:Profile){setProfile(next);setEntered(true);setEditingProfile(false);setScene('home');setItem(null);setPanel(null);setSeenIds([]);setMessage('');}
 async function startSpin(target?:SpinCategory){
  const reduced=motionReduced();performanceEvent('spin_requested',{reduced:Number(reduced),locked:Number(locked.current),targeted:Number(Boolean(target))});
  if(locked.current)return;adEvent('busy');void sfx.current?.unlock();locked.current=true;setBusy(true);setPanel(null);setMessage('');setDetails(false);
  let currentProfile=profile;
  if(scene==='result'&&item&&!profile.completedIds.includes(item.id)&&!profile.events.some(e=>e.itemId===item.id&&e.kind==='accept')){currentProfile=recordSignal(profile,item,'skip');setProfile(currentProfile);}
  let current:ContentRecord[];try{current=await readPreviewCatalog();setPublished(approvedCatalog(current));setCatalogState(consumerCatalogStatus().source);setCatalogError('');}catch(error){const code=catalogFailure(error);setCatalogState('error');setCatalogError(code);setMessage((locale==='en'?'Online library could not be loaded.':'Online biblioteka se nije učitala.')+' · '+code);locked.current=false;setBusy(false);return;}
  const catalog:PreviewRecord[]=approvedCatalog(current);
  const eligible=cycleCandidates(catalog,currentProfile,seenIds);
  const selected=target??choosePersonalizedCategory(eligible,currentProfile,lastCategory.current);
  if(!selected){setMessage("Nema novih odobrenih ONLINE izbora za tvoje preference. Provjeri objave u Studiju ili vrati prethodne prijedloge.");locked.current=false;setBusy(false);return;}
  const targetIndex=WHEEL_CATEGORIES.findIndex(c=>c.id===selected);lastCategory.current=selected;
  const categoryCandidates=cycleCandidates(catalog.filter(r=>uiCategory(r)===selected),currentProfile,seenIds);
  const recommendation=selectPersonalized(categoryCandidates,currentProfile,[]);
  const visualChoices=target&&recommendation?itemWheelChoices(categoryCandidates,recommendation):null;
  setWheelChoices(visualChoices);setPointerChoice(0);
  const landingIndex=visualChoices?visualChoices.findIndex(r=>r.id===recommendation?.id):targetIndex;const segmentCount=visualChoices?.length??WHEEL_CATEGORIES.length;
  performanceEvent('spin_stage',{stage:1,reduced:Number(reduced)});
  await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));
  if(scene==='result'){setScene('home');await new Promise(r=>setTimeout(r,reduced?0:340));}
  const frameTimes:number[]=[];let previousFrame=0,wasHidden=false;
  const from=rotation.current,to=landingRotation(from,landingIndex,6,segmentCount),began=performance.now(),duration=reduced?0:4800;sfx.current?.spin(duration);
  await new Promise<void>(resolve=>{let previous=-1;const frame=(now:number)=>{if(previousFrame&&frameTimes.length<1500)frameTimes.push(now-previousFrame);previousFrame=now;wasHidden||=document.hidden;if(!mounted.current){resolve();return;}const progress=duration?Math.min(1,(now-began)/duration):1;rotation.current=from+(to-from)*coast(progress);if(rotor.current)rotor.current.style.transform=`rotate(${rotation.current}deg)`;const index=sectorAtRotation(rotation.current,segmentCount);if(index!==previous){previous=index;if(visualChoices){setActive(targetIndex);setPointerChoice(index);}else setActive(index);setTick(v=>v+1);if(!reduced)sfx.current?.tick();}if(progress<1)animation.current=requestAnimationFrame(frame);else resolve();};animation.current=requestAnimationFrame(frame);});
  performanceEvent('spin',summarizeFrames(frameTimes,wasHidden,reduced,performance.now()-began));
  await new Promise(r=>setTimeout(r,reduced?0:450));if(!mounted.current)return;setActive(targetIndex);
  performanceEvent('spin_stage',{stage:2,reduced:Number(reduced)});
  if(recommendation){sfx.current?.finish();expose(recommendation);adEvent('spin');}else{setItem(null);setMessage("Nema novog izbora za ova ograničenja. Vrati prethodne prijedloge ili izmijeni profil.");}
  locked.current=false;setBusy(false);
 }
 function goHome(){if(busy||locked.current)return;adEvent(scene==='result'&&!visiblePanel&&!details&&!editingProfile&&!imageExpanded&&entered&&launchPhase==='ready'?'home':'busy');setWheelChoices(null);setScene('home');setPanel(null);setDetails(false);}
 function toggleFavorite(event?:React.MouseEvent<HTMLButtonElement>){if(!item)return;const removing=favoriteIds.includes(item.id);setFavoriteIds(ids=>removing?ids.filter(id=>id!==item.id):[...ids,item.id].slice(-200));if(!removing){sfx.current?.save();signal(item,'save');setSaveNotice(locale==='en'?'Saved to favorites':'Sačuvano u favorite');const card=document.querySelector('.random-card')?.getBoundingClientRect();const origin=event?.currentTarget.getBoundingClientRect();const target=document.querySelector('[data-nav="favorites"]')?.getBoundingClientRect();if(card&&origin&&target){setSaveFlight({id:Date.now(),x:origin.x+origin.width/2-card.x,y:origin.y+origin.height/2-card.y,toX:target.x+target.width/2-card.x,toY:target.y+target.height/2-card.y,label:locale==='en'?'Saved to favorites':'Sačuvano u favorite'});}}else{setSaveFlight(null);setSaveNotice(locale==='en'?'Removed from favorites':'Uklonjeno iz favorita');}}
 useEffect(()=>{if(!saveFlight)return;const timer=setTimeout(()=>setSaveFlight(null),900);return()=>clearTimeout(timer);},[saveFlight]);
 useEffect(()=>{if(!saveNotice)return;const timer=setTimeout(()=>setSaveNotice(''),1800);return()=>clearTimeout(timer);},[saveNotice]);
 function acceptItem(){if(!item)return;signal(item,'accept');setDetails(true);setPanel(null);}
 function openCompanion(companion:Companion){const target=records.find(r=>r.id===companion.targetId);if(target&&eligibleForProfile(target,profile)){setPanel(null);setDetails(false);expose(target);signal(target,'accept');}else{setRelatedInfo(companion);setPanel('related-info');}}
 const d=item?localizeContent(item,locale):null;
 const saved=!!item&&favoriteIds.includes(item.id);const contextual=visiblePanel==='ingredients'||visiblePanel==='companions';
 const displayedRelated=relatedInfo&&item?companionItems(item,locale,records).find(c=>c.id===relatedInfo.id)??relatedInfo:relatedInfo;
 const relatedTitle=item?.category==='BOOK'?t("Još od ovog autora"):item?.category==='WATCH'?t("Slične priče"):item?.category==='MOVE'?t("Za ovu aktivnost"):t("Prije nego kreneš");
 if(studio)return <div className="preview-studio-shell"><div className="studio-return"><a href="#"><Icon name="back" size={20}/>{t("Nazad u LifeSpinner")}</a><span>{locale==='en'?'Content Studio · shared D1':'Content Studio · zajednički D1'}</span></div><ContentStudio locale={locale} preview samples={[]}/></div>;
 if(launchPhase==='splash')return <div className="random-world"><div className="random-card launch-splash-card"><AppSplash/></div><p className="preview-footer splash-footer-placeholder" aria-hidden="true">LifeSpinner</p></div>;
 return <div className="random-world"><div className={`random-card ${entered?'entered':''} ${busy?'spinning':''} ${scene==='result'&&details?'item-focused':''} ${launchPhase==='reveal'?'launch-reveal':''}`}>
  {catalogState==='backup'&&<div className="backup-status" role="status">D1 disconnected · Backup active</div>}
  <ArtworkMasks/><div className="card-grain"/><div className="main-stage" inert={!entered||!!visiblePanel||editingProfile} aria-hidden={!entered}>
   <header className={`random-header ${scene==='result'?'result-header':''}`}><button ref={mainMenuButton} className="icon-button menu-button" aria-label={scene==='home'?t("Otvori meni"):details?(locale==='en'?'Back to item':'Nazad na item'):t("Nazad na Home")} disabled={busy} onClick={()=>scene==='home'?setPanel('menu'):details?setDetails(false):goHome()}><Icon name={scene==='home'?'menu':'back'} size={26}/></button>{scene==='home'&&<div className="wordmark"><h1><BrandLogo/></h1><p>{t("Decide Less. Live More.")}</p></div>}</header>
   <section className={`home-scene scene ${scene==='home'?'scene-visible':''}`} inert={scene!=='home'} aria-hidden={scene!=='home'}><Wheel rotor={rotor} tick={tick} spinning={busy} choices={wheelChoices} onSpin={()=>startSpin()} onSpinCategory={selected=>startSpin(selected)}/>{showSpinCaption&&<div className="wheel-caption" role="status"><span>{busy?t("Samo trenutak…"):`${t("Tvoj sljedeći trenutak")}, ${profile.name||t("istraživaču")}.`}</span><p>{busy?(wheelChoices?localizeContent(wheelChoices[pointerChoice]??wheelChoices[0],locale).title:category(WHEEL_CATEGORIES[active].id)):profile.personalization?t("Tvoji interesi. Malo iznenađenja."):(locale==='en'?'A fresh pick. A little surprise.':'Novi izbor. Malo iznenađenja.')}</p></div>}</section>
   <section className={`result-scene scene category-${item?uiCategory(item).toLowerCase():''} ${d&&(d.title.length>50||d.summary.length>350)?'long-content':''} ${scene==='result'?'scene-visible':''} ${details?'show-details':''}`} aria-hidden={scene!=='result'}>{item&&d&&<>
    <div className="result-overview" key={item.id}><span className="item-photo-ornament" aria-hidden="true"/><button type="button" className={`feature-photo photo-expand ${imageClass(item)} ${d.image.provenance?'real-cover':''}`} aria-label={locale==='en'?`View full image: ${d.title}`:`Prikaži cijelu sliku: ${d.title}`} disabled={!uploadedImage||details} onClick={()=>setImageExpanded(true)} style={uploadedImage?{backgroundImage:`url(${uploadedImage})`}:undefined}>{d.category==='WATCH'&&d.platform&&<span className={`streaming-badge ${d.platform.toLowerCase().includes('netflix')?'netflix':''}`} aria-label={`Streaming: ${d.platform}`}>{d.platform}</span>}</button>{!details&&<ItemActions item={item} locale={locale} liked={saved} completed={profile.completedIds.includes(item.id)} onLike={toggleFavorite} onCompleted={()=>setProfile(p=>toggleCompleted(p,item.id))}/>}
    <div className="result-copy" inert={details}><div className="result-copy-scroll"><p className="eyebrow">{t("TODAY’S PICK")} · {category(uiCategory(item))}</p><div className="result-heading-row"><ResultMeta item={d}/><div className="result-title-block"><h2 className={d.title.length>18?'long-title':undefined}><span className="action-prefix">{action(item,locale)}</span><span className="result-item-title">{d.title}</span></h2>{d.category==='BOOK'&&<p className="book-author">{d.authors.join(', ')}</p>}{d.category==='WATCH'&&<p className="book-author">{value(d.format)}</p>}</div><p className="result-summary">{d.summary}</p></div>{d.image.provenance&&<p className="cover-credit"><a href={d.image.provenance.sourceUrl} target="_blank" rel="noreferrer">{d.image.provenance.provider}</a> · {d.image.provenance.attribution}</p>}</div></div>
    </div><div className="result-actions" inert={details}><button className="pill-primary" disabled={busy} onClick={acceptItem}><Icon name={actionIcon(item)} size={22}/>{actionLabel(item,locale)}<Icon name="arrow" size={21}/></button></div>
    <div className="details-screen" inert={!details} aria-hidden={!details}><div className="detail-hero">{details&&<ItemActions item={item} locale={locale} liked={saved} completed={profile.completedIds.includes(item.id)} onLike={toggleFavorite} onCompleted={()=>setProfile(p=>toggleCompleted(p,item.id))}/>}<span className="detail-photo-ornament" aria-hidden="true"/><button type="button" className={`detail-photo photo-expand ${imageClass(item)} ${d.image.provenance?'real-cover':''}`} aria-label={locale==='en'?`View full image: ${d.title}`:`Prikaži cijelu sliku: ${d.title}`} disabled={!uploadedImage} onClick={()=>setImageExpanded(true)} style={uploadedImage?{backgroundImage:`url(${uploadedImage})`}:undefined}><span className="detail-full-image" aria-hidden="true" style={uploadedImage?{backgroundImage:`url(${uploadedImage})`}:undefined}/>{d.category==='WATCH'&&d.platform&&<span className={`streaming-badge ${d.platform.toLowerCase().includes('netflix')?'netflix':''}`} aria-label={`Streaming: ${d.platform}`}>{d.platform}</span>}</button></div><div className="detail-reading-surface"><div className="detail-heading"><p className="eyebrow">{d.category==='EAT'?t("COOK"):d.category==='WATCH'?category('WATCH'):category(uiCategory(item))}</p><h2>{d.title}</h2>{d.category==='BOOK'&&<p className="book-author">{d.authors.join(', ')}</p>}{d.category==='EAT'?<div className="detail-meta"><span><Icon name="clock" size={21}/>{d.totalMinutes} min</span><span><Icon name="chef" size={21}/>{t("Lako")}</span><button onClick={()=>setPanel('ingredients')}><Icon name="people" size={21}/>{d.servings} {t("osobe")} · {t("sastojci")}</button></div>:(d.category==='MOVE'||d.category==='GO')?<div className="detail-meta"><span><Icon name="clock" size={21}/>{d.durationMinutes} min · {t("okvirni plan")}</span><span><Icon name={actionIcon(item)} size={21}/>{value(d.subtype)}</span></div>:null}</div>
     <div className="detail-sheet"><div className="detail-content"><h3>{d.category==='EAT'?t("Kratki postupak"):d.category==='BOOK'?t("Zašto ova knjiga?"):d.category==='WATCH'?t("Zašto ovaj izbor?"):d.category==='MOVE'?t("Tvoj mali plan"):t("Plan za izlazak")}</h3>{d.category==='EAT'||d.category==='MOVE'||d.category==='GO'?d.steps.map((step,i)=><div className="recipe-step" key={i}><span>{i+1}</span><p>{step}</p></div>):<><p className="reading-reason">{d.recommendationReason}</p><div className="genre-tags">{d.genres.map(g=><span key={g}>{g}</span>)}</div></>}
      <AccessLinks item={item} locale={locale}/><p className="personalization-reason">{t(explainPreference(item,profile))}</p></div>
     </div></div>
    </div>
   </>}</section>
   <nav className="bottom-nav" inert={details} aria-hidden={details} aria-label={t("Glavna navigacija")}><button className={scene==='home'?'active':''} onClick={goHome} disabled={busy} aria-label={t("Home")}><Icon name="home" size={21}/><span>{t("Home")}</span></button><button data-nav="favorites" className={saveFlight?'favorite-arrival':''} onClick={()=>setPanel('favorites')} disabled={busy} aria-label={t("Favoriti")}><Icon name="heart" size={23}/></button><button onClick={()=>setPanel('history')} disabled={busy} aria-label={t("Historija izbora")}><Icon name="chart" size={23}/></button><button onClick={()=>setPanel('profile')} disabled={busy} aria-label={t("Profil i ograničenja")}><Icon name="profile" size={23}/></button></nav>
   {scene==='result'&&details&&item&&d&&<div className="detail-controls detail-action-bar"><button type="button" ref={detailHomeButton} className="icon-button detail-home-button" onClick={goHome} aria-label={locale==='en'?'Back to main menu':'Nazad na glavni meni'} title={locale==='en'?'Back to main menu':'Nazad na glavni meni'}><Icon name="house" size={25}/></button><button className="pill-primary" onClick={()=>setPanel(d.category==='EAT'?'ingredients':'companions')}><Icon name={actionIcon(item)} size={21}/>{d.category==='EAT'?t("SASTOJCI"):d.category==='BOOK'?t("ISTI AUTOR"):d.category==='WATCH'?t("SLIČNI NASLOVI"):t("JOŠ ZA OVAJ IZBOR")}</button></div>}
   {!!message&&<div className="empty-notice" role="status"><p>{t(message)}</p><button onClick={()=>{setSeenIds([]);setMessage('');}}>{t("Vrati prethodne prijedloge")}</button></div>}
  </div>
  <aside className="category-rail" inert={details||!entered||!!visiblePanel||editingProfile} aria-hidden={details||!entered}><p className="your-spin">{t("Choose")}<br/>{t("category")}</p><div className="rail-categories">{WHEEL_CATEGORIES.map((c,i)=><button key={c.id} className={`rail-category ${active===i?'selected':''} ${c.enabled?'enabled':'coming-soon'}`} aria-label={`${category(c.id)}${c.enabled?'':` — ${t("Uskoro")}`}`} aria-pressed={active===i} disabled={busy||!c.enabled} onClick={()=>startSpin(c.id as SpinCategory)}><span className="category-pictogram" aria-hidden="true"><Icon name={c.icon} size={30}/></span><span className="rail-label">{category(c.id)}</span>{!c.enabled&&<span className="soon-dot" title={t("Uskoro")}/>}</button>)}</div><button className="rail-respin" onClick={()=>startSpin(scene==='result'&&item?uiCategory(item):undefined)} disabled={busy} aria-label={t("Spin again")}><span><Icon name="refresh" size={25}/></span><small>{t("Spin again")}</small></button></aside>
  {visiblePanel&&<div className={`panel-scrim ${contextual?'context-drawer':''} ${!panel?'panel-closing':''}`} onClick={()=>setPanel(null)}><section className={`floating-panel ${contextual?'ingredient-panel companion-panel':''}`} role="dialog" aria-modal="true" aria-hidden={!panel} aria-label={visiblePanel==='ingredients'?t("Sastojci"):visiblePanel==='companions'?relatedTitle:visiblePanel==='profile'?t("Tvoj profil"):t("LifeSpinner meni")} onClick={e=>e.stopPropagation()}><button className="panel-close" onClick={()=>setPanel(null)} aria-label={t("Zatvori panel")}><Icon name="close" size={25}/></button>
   {visiblePanel==='ingredients'&&item?.category==='EAT'&&d?.category==='EAT'&&<><h3>{t("Sastojci")}</h3><p>{t("Za")} {item.servings} {t("osobe")}</p><div className="ingredients">{d.ingredients.map((ingredient,i)=>{const tag=resolveIngredient(item.ingredients[i].name,item.ingredients[i].tag);return <div key={i}><span className={`ingredient-symbol ${tag?'tagged-ingredient':''} ${tag?.atlas==='extension-74'?'ingredient-atlas-extension-74':''}`} style={tag?ingredientSpriteStyle(tag):{backgroundImage:'none'}} data-ingredient-tag={tag?.id??'unknown'}>{!tag&&<Icon name="food" size={22}/>}</span><div><strong>{ingredient.name}</strong><small>{ingredient.quantity??''} {ingredient.unit}</small></div></div>;})}</div><p className="allergen-note">{t("Alergeni")}: {item.allergens.map(value).join(', ')||t("nema evidentiranih")}. {t("Provjeri sastojke i pakovanja.")}</p></>}
   {visiblePanel==='companions'&&item&&d&&<><h3>{relatedTitle}</h3><p>{d.category==='BOOK'?d.authors.join(', '):item.category==='WATCH'?t("Preporuke po temi"):item.category==='MOVE'?t("Oprema i još jedna ideja"):t("Mali podsjetnik za izlazak")}</p>{(d.category==='MOVE'||d.category==='GO')&&<div className="companion-checklist">{(d.category==='MOVE'?d.equipment:d.steps).map((text,i)=><p key={i}><Icon name={item.category==='MOVE'?'move':'pin'} size={18}/>{text}</p>)}</div>}<div className="companion-list">{companionItems(item,locale,records).map(c=>{const target=records.find(r=>r.id===c.targetId);return <button className="companion-entry" key={c.id} onClick={()=>openCompanion(c)} disabled={!!target&&!eligibleForProfile(target,profile)}><span className="companion-thumb">{target?<SavedPhoto record={target}/>:<Icon name={c.category==='BOOK'?'book':c.category==='WATCH'?'watch':c.category==='MOVE'?'move':'pin'} size={18}/>}</span><span><strong>{c.title}</strong><small>{c.subtitle}</small></span><Icon name="arrow" size={15}/></button>;})}</div></>}
   {visiblePanel==='related-info'&&relatedInfo&&<><p className="eyebrow">{relatedInfo.category==='BOOK'?t("JOŠ OD OVOG AUTORA"):t("SRODAN NASLOV")}</p><h3>{displayedRelated?.title}</h3><p className="panel-note">{displayedRelated?.subtitle}</p><p className="panel-note">{t("Bibliografski prijedlog za istraživanje. Ovo nije prikaz izdanja ili dostupnosti za gledanje.")}</p><button className="pill-primary" onClick={()=>setPanel('companions')}>{t("NAZAD NA NASLOVE")}</button></>}
   {visiblePanel==='menu'&&<><LanguageChooser/><button className="panel-menu-item" aria-pressed={soundEnabled} onClick={changeSound}>{locale==='en'?'Sound effects':'Zvučni efekti'} · {soundEnabled?(locale==='en'?'On':'Uključeni'):(locale==='en'?'Off':'Isključeni')}</button><button className="panel-menu-item" onClick={()=>{void exportPerformance().catch(()=>setMessage(locale==='en'?'Could not share diagnostic log. Please try again.':'Log nije podijeljen. Pokušaj ponovo.'));}}>{locale==='en'?'Share diagnostic log':'Podijeli dijagnostički log'}</button><p className="eyebrow">LifeSpinner</p><h3>{t("Decide less.")}<br/>{t("Live more.")}</h3><button className="panel-menu-item" onClick={()=>setPanel('profile')}><Icon name="profile"/>{t("Moj profil")}</button><button className="panel-menu-item" onClick={()=>setPanel('favorites')}><Icon name="heart"/>{t("Sačuvani izbori")}</button><p className="panel-note">{["EAT","READ","WATCH","MOVE","GO"].map(category).join(", ")} {t("su aktivni u testu.")}</p></>}
   {visiblePanel==='profile'&&<><p className="eyebrow">{t("TVOJ IZBOR")}</p><h3>{t("Zdravo")}, {profile.name||t("istraživaču")}.</h3><p className="panel-note">{t("Profil je na ovom uređaju.")} {storageAvailable?t("Vraćaš se bez ponovnog unosa."):t("Preglednik ne dopušta trajno čuvanje; profil ostaje samo tokom ove posjete.")}</p><div className="profile-interests">{profile.interests.map(c=><span key={c}>{category(c)}</span>)}</div><p className="panel-note">{t("Teme")}: {profile.topics.map(value).join(', ')||t("otvoren/a za iznenađenja")}.<br/>{t("Ograničenja")}: {profile.allergens.map(value).join(', ')||t("nema odabranih alergena")}{profile.lowPhosphateDiet?t(" · prehrana s malo fosfora"):""}{profile.vegan?(locale==='en'?' · vegan':' · vegansko'):profile.vegetarian?t(" · vegetarijansko"):''}.<br/>{t("Intolerancije")}: {profile.intolerances.map(value).join(', ')||t("nisu odabrane")}{profile.intoleranceNote?` · ${profile.intoleranceNote}`:''}.</p><label className="preference-check"><input type="checkbox" checked={profile.personalization} onChange={e=>setProfile(p=>setPersonalization(p,e.target.checked))}/>{locale==='en'?'Personalize suggestions':'Personalizacija prijedloga'}</label>{profile.personalization&&<label className="preference-check"><input type="checkbox" checked={profile.learning} onChange={e=>setProfile(p=>({...p,learning:e.target.checked}))}/>{t("Uči iz mojih izbora")}</label>}<div className="profile-stats"><span><strong>{profile.events.filter(e=>e.kind==='accept').length}</strong>{t("odabira")}</span><span><strong>{favoriteIds.filter(id=>!id.startsWith('listen:')).length}</strong>{t("sačuvano")}</span><span><strong>{profile.events.filter(e=>e.kind==='skip').length}</strong>{t("preskočeno")}</span></div><button className="pill-primary" onClick={()=>{setPanel(null);setEditingProfile(true);}}>{t("UREDI ODGOVORE")}</button><button className="profile-reset" onClick={()=>setProfile(p=>({...p,events:[]}))}>{t("Obriši naučene preferencije")}</button><button className="profile-reset" onClick={()=>{if(window.confirm(t("Obrisati profil, historiju i favorite na ovom uređaju?"))){try{deleteDeviceProfile(localStorage);}catch{}const next=createProfile();setProfile(next);setFavoriteIds([]);setSeenIds([]);setHistoryIds([]);setEntered(false);setWelcomeRendered(true);setPanel(null);goHome();}}}>{locale==='en'?'Delete profile & data':'Obriši profil i podatke'}</button>{hasNativeAds()&&<button className="profile-reset" onClick={()=>adEvent('privacy')}>{locale==='en'?'Ad privacy choices':'Privatnost oglasa'}</button>}<ShareAppControl locale={locale}/><CatalogControls locale={locale}/><p className="panel-note"><a href="https://random-life-preview.pages.dev/terms.html" target="_blank" rel="noreferrer">{locale==='en'?'Terms of use':'Uslovi korištenja'}</a> · <a href="https://random-life-preview.pages.dev/privacy.html" target="_blank" rel="noreferrer">{locale==='en'?'Privacy Policy':'Politika privatnosti'}</a> · <a href="https://random-life-preview.pages.dev/delete-data.html" target="_blank" rel="noreferrer">{locale==='en'?'Data deletion':'Brisanje podataka'}</a></p></>}
   {(visiblePanel==='favorites'||visiblePanel==='history')&&<><p className="eyebrow">{t("TVOJI TRENUTCI")}</p><h3>{visiblePanel==='favorites'?t("Sačuvaj ono dobro."):t("Tvoji dosadašnji izbori.")}</h3>{(visiblePanel==='favorites'?favoriteIds:[...historyIds].reverse()).filter(id=>!id.startsWith('listen:')).length?(visiblePanel==='favorites'?favoriteIds:[...historyIds].reverse()).filter(id=>!id.startsWith('listen:')).map((id,i)=>{const r=records.find(v=>v.id===id);if(!r)return null;return <button className="saved-item" key={`${id}-${i}`} disabled={!eligibleForProfile(r,{...profile,completedIds:[]})} onClick={()=>{setItem(r);setScene('result');setDetails(false);setPanel(null);setActive(WHEEL_CATEGORIES.findIndex(c=>c.id===uiCategory(r)));signal(r,'open');}}><SavedPhoto record={r}/><span><small>{category(uiCategory(r))}</small><strong>{localizeContent(r,locale).title}</strong>{profile.completedIds.includes(r.id)?<small>{completedLabel(r,locale)}</small>:!eligibleForProfile(r,profile)&&<small>{t("Ne odgovara tvojim ograničenjima")}</small>}</span><Icon name="arrow" size={18}/></button>;}):<p className="panel-note">{t("Još nema izbora. Isprobaj Spin.")}</p>}</>}
  </section></div>}
  {imageExpanded&&uploadedImage&&d&&<ImageViewer src={uploadedImage} alt={d.image.alt} title={d.title} locale={locale} onClose={()=>setImageExpanded(false)}/>}
  {saveFlight&&<div key={saveFlight.id} className="save-flight" aria-hidden="true" style={{'--from-x':`${saveFlight.x}px`,'--from-y':`${saveFlight.y}px`,'--to-x':`${saveFlight.toX}px`,'--to-y':`${saveFlight.toY}px`} as React.CSSProperties}><Icon name="mail" size={25}/></div>}
  {saveNotice&&<div className="save-notice" role="status">{saveNotice}</div>}
  {launchPhase==='reveal'&&<AppSplash leaving/>}
  {welcomeRendered&&<Onboarding profile={profile} leaving={entered} onComplete={finishProfile}/>}
  {editingProfile&&<><Onboarding profile={profile} editing onComplete={finishProfile} onCancel={()=>setEditingProfile(false)}/><button className="cancel-profile-edit" onClick={()=>window.dispatchEvent(new Event('lifespinner.profile-cancel'))} aria-label={t("Otkaži uređivanje profila")}><Icon name="close" size={24}/></button></>}
 </div><p className="preview-footer" role="status">LifeSpinner · <span className={`catalog-connection catalog-${catalogState}`}>{catalogState==='backup'?`Backup · ${published.length} items`:catalogState==='cached'?`${locale==='en'?'Saved catalog':'Sačuvani katalog'} · ${published.length}`:catalogState==='online'?`CATALOG ONLINE · ${published.length} ${locale==='en'?'published items':'objavljenih stavki'}`:catalogState==='loading'?(locale==='en'?'Connecting to D1…':'Povezivanje na D1…'):(locale==='en'?'Library request failed':'Zahtjev biblioteci nije uspio')+' · '+catalogError}</span>{catalogState==='error'&&<button onClick={()=>{setCatalogState('loading');setCatalogReload(v=>v+1);}}>{locale==='en'?'Retry':'Pokušaj ponovo'}</button>}</p></div>;
}
